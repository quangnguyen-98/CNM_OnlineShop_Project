




     module.exports = 'http://hqkclient.us-west-1.elasticbeanstalk.com/BaiViets/';



    // module.exports = 'http://localhost:3004/BaiViets/';



   // module.exports = 'https://clientprojectonlineshop.herokuapp.com/BaiViets/';
