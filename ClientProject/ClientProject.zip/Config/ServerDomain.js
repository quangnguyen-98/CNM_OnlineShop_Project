



                   module.exports = 'http://hqkserver.us-west-1.elasticbeanstalk.com/api';



             //    module.exports = 'http://localhost:3001/api';

                   // module.exports = 'https://serverproject.herokuapp.com/api';
