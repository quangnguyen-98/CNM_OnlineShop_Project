var express = require('express');
var router = express.Router();
const app = express();

//Khai báo conntroller
var NguoiDungController = require('../controller/NguoiDung.controller');

/* GET trang chủ */





module.exports = router;
